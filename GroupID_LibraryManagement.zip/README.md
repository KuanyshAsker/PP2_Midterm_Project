# Library Management System

A console-based Python and SQLite project for the Python midterm.

## Run

Python 3.10 or newer is recommended. From this folder, run:

```bash
python3 main.py
```

The application creates `project.db` on first launch and loads a deterministic demo dataset with 50 books, 30 members, and 30 borrowings. The `Random` module is used for repeatable sample return dates. ISBN and email input are checked with regular expressions.

## Features

- Add books, members, and borrowing records
- Display books, members, and borrowing history
- Search books by title and members by name or ID
- List available books
- Update and delete books; cancel or return borrowings
- Report borrowing totals, active loans, and the most frequently borrowed book
- Export a CSV report with summary statistics and borrowing records
- Three related SQLite tables with foreign keys

The initial dataset and names are fictional demonstration data. Replace the team-member placeholders in the report and presentation before submission.
